# Squirrel
A squirrel hides nuts to prepare for the winter season. Can you find where the squirrel hid the flag?

## Summary
+ **Author:** Jerald Yeo
+ **Discord Tag:** maximus#4723
+ **Category:** Forensics
+ **Difficulty:** Easy

## Solution
1. Run `strings` on the challenge image. The flag is near the end of the file.

## Flag
```
YCEP2023{57R1NG5_1N_1M4G35}
```